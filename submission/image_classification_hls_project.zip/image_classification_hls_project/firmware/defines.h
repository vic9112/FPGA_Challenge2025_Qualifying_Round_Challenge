#ifndef DEFINES_H_
#define DEFINES_H_

#include "ap_fixed.h"
#include "ap_int.h"
#include "nnet_utils/nnet_types.h"
#include <cstddef>
#include <cstdio>

// hls-fpga-machine-learning insert numbers
#define N_INPUT_1_1 32
#define N_INPUT_2_1 32
#define N_INPUT_3_1 3
#define OUT_HEIGHT_22 34
#define OUT_WIDTH_22 34
#define N_CHAN_22 3
#define OUT_HEIGHT_2 32
#define OUT_WIDTH_2 32
#define N_FILT_2 16
#define OUT_HEIGHT_2 32
#define OUT_WIDTH_2 32
#define N_FILT_2 16
#define OUT_HEIGHT_23 34
#define OUT_WIDTH_23 34
#define N_CHAN_23 16
#define OUT_HEIGHT_5 32
#define OUT_WIDTH_5 32
#define N_FILT_5 16
#define OUT_HEIGHT_5 32
#define OUT_WIDTH_5 32
#define N_FILT_5 16
#define OUT_HEIGHT_8 16
#define OUT_WIDTH_8 16
#define N_FILT_8 16
#define OUT_HEIGHT_24 18
#define OUT_WIDTH_24 18
#define N_CHAN_24 16
#define OUT_HEIGHT_9 16
#define OUT_WIDTH_9 16
#define N_FILT_9 20
#define OUT_HEIGHT_9 16
#define OUT_WIDTH_9 16
#define N_FILT_9 20
#define OUT_HEIGHT_25 18
#define OUT_WIDTH_25 18
#define N_CHAN_25 20
#define OUT_HEIGHT_12 16
#define OUT_WIDTH_12 16
#define N_FILT_12 20
#define OUT_HEIGHT_12 16
#define OUT_WIDTH_12 16
#define N_FILT_12 20
#define N_FILT_15 20
#define N_LAYER_16 20
#define N_LAYER_16 20
#define N_LAYER_16 20
#define N_LAYER_20 10


// hls-fpga-machine-learning insert layer-precision
typedef nnet::array<ap_ufixed<8,0>, 3*1> input_t;
typedef nnet::array<ap_ufixed<8,0>, 3*1> layer22_t;
typedef ap_fixed<22,9> q_conv2d_batchnorm_accum_t;
typedef nnet::array<ap_fixed<22,9>, 16*1> q_conv2d_batchnorm_result_t;
typedef ap_fixed<8,3> weight2_t;
typedef ap_fixed<8,3> bias2_t;
typedef nnet::array<ap_ufixed<8,2,AP_RND_CONV,AP_SAT,0>, 16*1> layer4_t;
typedef ap_fixed<18,8> q_activation_table_t;
typedef nnet::array<ap_ufixed<8,2,AP_RND_CONV,AP_SAT,0>, 16*1> layer23_t;
typedef ap_fixed<25,14> q_conv2d_batchnorm_1_accum_t;
typedef nnet::array<ap_fixed<25,14>, 16*1> q_conv2d_batchnorm_1_result_t;
typedef ap_fixed<8,3> weight5_t;
typedef ap_fixed<8,3> bias5_t;
typedef nnet::array<ap_ufixed<8,2,AP_RND_CONV,AP_SAT,0>, 16*1> layer7_t;
typedef ap_fixed<18,8> q_activation_1_table_t;
typedef ap_ufixed<8,2,AP_RND_CONV,AP_SAT,0> max_pooling2d_accum_t;
typedef nnet::array<ap_ufixed<8,2,AP_RND_CONV,AP_SAT,0>, 16*1> layer8_t;
typedef nnet::array<ap_ufixed<8,2,AP_RND_CONV,AP_SAT,0>, 16*1> layer24_t;
typedef ap_fixed<25,14> q_conv2d_batchnorm_2_accum_t;
typedef nnet::array<ap_fixed<25,14>, 20*1> q_conv2d_batchnorm_2_result_t;
typedef ap_fixed<8,3> weight9_t;
typedef ap_fixed<8,3> bias9_t;
typedef nnet::array<ap_ufixed<8,2,AP_RND_CONV,AP_SAT,0>, 20*1> layer11_t;
typedef ap_fixed<18,8> q_activation_2_table_t;
typedef nnet::array<ap_ufixed<8,2,AP_RND_CONV,AP_SAT,0>, 20*1> layer25_t;
typedef ap_fixed<25,14> q_conv2d_batchnorm_3_accum_t;
typedef nnet::array<ap_fixed<25,14>, 20*1> q_conv2d_batchnorm_3_result_t;
typedef ap_fixed<8,3> weight12_t;
typedef ap_fixed<8,3> bias12_t;
typedef nnet::array<ap_ufixed<8,2,AP_RND_CONV,AP_SAT,0>, 20*1> layer14_t;
typedef ap_fixed<18,8> q_activation_3_table_t;
typedef ap_fixed<18,8> global_average_pooling2d_accum_t;
typedef nnet::array<ap_fixed<18,8>, 20*1> layer15_t;
typedef ap_fixed<32,17> q_dense_accum_t;
typedef nnet::array<ap_fixed<32,17>, 20*1> q_dense_result_t;
typedef ap_fixed<8,3> weight16_t;
typedef ap_fixed<18,8> q_dense_bias_t;
typedef ap_uint<1> layer16_index;
typedef nnet::array<ap_fixed<51,26>, 20*1> batch_normalization_4_result_t;
typedef ap_fixed<18,8> batch_normalization_4_scale_t;
typedef ap_fixed<18,8> batch_normalization_4_bias_t;
typedef nnet::array<ap_ufixed<8,2,AP_RND_CONV,AP_SAT,0>, 20*1> layer19_t;
typedef ap_fixed<18,8> q_activation_4_table_t;
typedef ap_fixed<22,11> q_dense_1_accum_t;
typedef nnet::array<ap_fixed<22,11>, 10*1> result_t;
typedef ap_fixed<8,3> weight20_t;
typedef ap_fixed<18,8> q_dense_1_bias_t;
typedef ap_uint<1> layer20_index;


#endif
