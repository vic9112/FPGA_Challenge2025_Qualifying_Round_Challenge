#include <iostream>

#include "myproject.h"
#include "parameters.h"


void myproject(
    hls::stream<input_t> &input_1,
    hls::stream<result_t> &layer20_out
) {

    // hls-fpga-machine-learning insert IO
    #pragma HLS INTERFACE axis port=input_1,layer20_out 
    #pragma HLS DATAFLOW

    // hls-fpga-machine-learning insert load weights
#ifndef __SYNTHESIS__
    static bool loaded_weights = false;
    if (!loaded_weights) {
        nnet::load_weights_from_txt<weight2_t, 432>(w2, "w2.txt");
        nnet::load_weights_from_txt<bias2_t, 16>(b2, "b2.txt");
        nnet::load_weights_from_txt<weight5_t, 2304>(w5, "w5.txt");
        nnet::load_weights_from_txt<bias5_t, 16>(b5, "b5.txt");
        nnet::load_weights_from_txt<weight9_t, 2880>(w9, "w9.txt");
        nnet::load_weights_from_txt<bias9_t, 20>(b9, "b9.txt");
        nnet::load_weights_from_txt<weight12_t, 3600>(w12, "w12.txt");
        nnet::load_weights_from_txt<bias12_t, 20>(b12, "b12.txt");
        nnet::load_weights_from_txt<weight16_t, 400>(w16, "w16.txt");
        nnet::load_weights_from_txt<q_dense_bias_t, 20>(b16, "b16.txt");
        nnet::load_weights_from_txt<batch_normalization_4_scale_t, 20>(s18, "s18.txt");
        nnet::load_weights_from_txt<batch_normalization_4_bias_t, 20>(b18, "b18.txt");
        nnet::load_weights_from_txt<weight20_t, 200>(w20, "w20.txt");
        nnet::load_weights_from_txt<q_dense_1_bias_t, 10>(b20, "b20.txt");
        loaded_weights = true;    }
#endif
    // ****************************************
    // NETWORK INSTANTIATION
    // ****************************************

    // hls-fpga-machine-learning insert layers

    hls::stream<layer22_t> layer22_out("layer22_out");
    #pragma HLS STREAM variable=layer22_out depth=1156
    nnet::zeropad2d_cl<input_t, layer22_t, config22>(input_1, layer22_out); // zp2d_q_conv2d_batchnorm

    hls::stream<q_conv2d_batchnorm_result_t> layer2_out("layer2_out");
    #pragma HLS STREAM variable=layer2_out depth=1024
    nnet::conv_2d_cl<layer22_t, q_conv2d_batchnorm_result_t, config2>(layer22_out, layer2_out, w2, b2); // q_conv2d_batchnorm

    hls::stream<layer4_t> layer4_out("layer4_out");
    #pragma HLS STREAM variable=layer4_out depth=1024
    nnet::relu<q_conv2d_batchnorm_result_t, layer4_t, relu_config4>(layer2_out, layer4_out); // q_activation

    hls::stream<layer23_t> layer23_out("layer23_out");
    #pragma HLS STREAM variable=layer23_out depth=1156
    nnet::zeropad2d_cl<layer4_t, layer23_t, config23>(layer4_out, layer23_out); // zp2d_q_conv2d_batchnorm_1

    hls::stream<q_conv2d_batchnorm_1_result_t> layer5_out("layer5_out");
    #pragma HLS STREAM variable=layer5_out depth=1024
    nnet::conv_2d_cl<layer23_t, q_conv2d_batchnorm_1_result_t, config5>(layer23_out, layer5_out, w5, b5); // q_conv2d_batchnorm_1

    hls::stream<layer7_t> layer7_out("layer7_out");
    #pragma HLS STREAM variable=layer7_out depth=1024
    nnet::relu<q_conv2d_batchnorm_1_result_t, layer7_t, relu_config7>(layer5_out, layer7_out); // q_activation_1

    hls::stream<layer8_t> layer8_out("layer8_out");
    #pragma HLS STREAM variable=layer8_out depth=256
    nnet::pooling2d_cl<layer7_t, layer8_t, config8>(layer7_out, layer8_out); // max_pooling2d

    hls::stream<layer24_t> layer24_out("layer24_out");
    #pragma HLS STREAM variable=layer24_out depth=324
    nnet::zeropad2d_cl<layer8_t, layer24_t, config24>(layer8_out, layer24_out); // zp2d_q_conv2d_batchnorm_2

    hls::stream<q_conv2d_batchnorm_2_result_t> layer9_out("layer9_out");
    #pragma HLS STREAM variable=layer9_out depth=256
    nnet::conv_2d_cl<layer24_t, q_conv2d_batchnorm_2_result_t, config9>(layer24_out, layer9_out, w9, b9); // q_conv2d_batchnorm_2

    hls::stream<layer11_t> layer11_out("layer11_out");
    #pragma HLS STREAM variable=layer11_out depth=256
    nnet::relu<q_conv2d_batchnorm_2_result_t, layer11_t, relu_config11>(layer9_out, layer11_out); // q_activation_2

    hls::stream<layer25_t> layer25_out("layer25_out");
    #pragma HLS STREAM variable=layer25_out depth=324
    nnet::zeropad2d_cl<layer11_t, layer25_t, config25>(layer11_out, layer25_out); // zp2d_q_conv2d_batchnorm_3

    hls::stream<q_conv2d_batchnorm_3_result_t> layer12_out("layer12_out");
    #pragma HLS STREAM variable=layer12_out depth=256
    nnet::conv_2d_cl<layer25_t, q_conv2d_batchnorm_3_result_t, config12>(layer25_out, layer12_out, w12, b12); // q_conv2d_batchnorm_3

    hls::stream<layer14_t> layer14_out("layer14_out");
    #pragma HLS STREAM variable=layer14_out depth=256
    nnet::relu<q_conv2d_batchnorm_3_result_t, layer14_t, relu_config14>(layer12_out, layer14_out); // q_activation_3

    hls::stream<layer15_t> layer15_out("layer15_out");
    #pragma HLS STREAM variable=layer15_out depth=1
    nnet::global_pooling2d_cl<layer14_t, layer15_t, config15>(layer14_out, layer15_out); // global_average_pooling2d

    hls::stream<q_dense_result_t> layer16_out("layer16_out");
    #pragma HLS STREAM variable=layer16_out depth=1
    nnet::dense<layer15_t, q_dense_result_t, config16>(layer15_out, layer16_out, w16, b16); // q_dense

    hls::stream<batch_normalization_4_result_t> layer18_out("layer18_out");
    #pragma HLS STREAM variable=layer18_out depth=1
    nnet::normalize<q_dense_result_t, batch_normalization_4_result_t, config18>(layer16_out, layer18_out, s18, b18); // batch_normalization_4

    hls::stream<layer19_t> layer19_out("layer19_out");
    #pragma HLS STREAM variable=layer19_out depth=1
    nnet::relu<batch_normalization_4_result_t, layer19_t, relu_config19>(layer18_out, layer19_out); // q_activation_4

    nnet::dense<layer19_t, result_t, config20>(layer19_out, layer20_out, w20, b20); // q_dense_1

}

