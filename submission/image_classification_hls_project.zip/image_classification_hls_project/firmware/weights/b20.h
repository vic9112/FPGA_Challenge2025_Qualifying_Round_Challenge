//Numpy array shape [10]
//Min -0.221567153931
//Max 0.303755491972
//Number of zeros 0

#ifndef B20_H_
#define B20_H_

#ifndef __SYNTHESIS__
q_dense_1_bias_t b20[10];
#else
q_dense_1_bias_t b20[10] = {-0.2110627443, 0.2121164948, -0.0380039029, 0.1779436916, -0.0849277601, -0.1372430772, 0.1294580847, -0.2215671539, -0.1626137495, 0.3037554920};

#endif

#endif
