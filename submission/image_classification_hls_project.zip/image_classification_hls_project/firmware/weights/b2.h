//Numpy array shape [16]
//Min -0.437500000000
//Max 0.187500000000
//Number of zeros 0

#ifndef B2_H_
#define B2_H_

#ifndef __SYNTHESIS__
bias2_t b2[16];
#else
bias2_t b2[16] = {-0.46875, 0.50000, 0.46875, 0.37500, -2.81250, 0.03125, 1.71875, 1.71875, 0.37500, 0.00000, -0.03125, 2.34375, 0.31250, 0.31250, 0.59375, 1.12500};

#endif

#endif
